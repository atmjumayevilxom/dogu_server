window.addEventListener('load', () => {
    document.getElementById('preload').remove();
});